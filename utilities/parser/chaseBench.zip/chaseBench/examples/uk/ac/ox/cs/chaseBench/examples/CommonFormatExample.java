package uk.ac.ox.cs.chaseBench.examples;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import uk.ac.ox.cs.chaseBench.format.CommonFormat;
import uk.ac.ox.cs.chaseBench.model.Atom;
import uk.ac.ox.cs.chaseBench.model.Constant;
import uk.ac.ox.cs.chaseBench.model.DatabaseSchema;
import uk.ac.ox.cs.chaseBench.model.LabeledNull;
import uk.ac.ox.cs.chaseBench.model.Rule;
import uk.ac.ox.cs.chaseBench.model.Term;
import uk.ac.ox.cs.chaseBench.parser.CSVParser;
import uk.ac.ox.cs.chaseBench.parser.CommonParser;
import uk.ac.ox.cs.chaseBench.processors.InputCollector;

public class CommonFormatExample {

    protected static void loadCommonFile(DatabaseSchema databaseSchema, File file, Set<Rule> rules, Set<Atom> facts) throws Exception {
        Reader fileReader = new FileReader(file);
        try {
            CommonParser parser = new CommonParser(fileReader);
            parser.parse(new InputCollector(databaseSchema, rules, facts));
        }
        finally {
            fileReader.close();
        }
    }

    public static void main(String[] args) throws Exception {
    	// This example demonstrates how to load and save data in the common format.
    	// All the data is located in the "scenario" subdirectory of this Eclipse project.
        File root = new File("scenario");
        Set<Rule> stDependencies = new LinkedHashSet<Rule>();
        Set<Rule> egds = new LinkedHashSet<Rule>();
        Set<Rule> queries = new LinkedHashSet<Rule>();
        Set<Atom> facts = new LinkedHashSet<Atom>();

        // We first load the schema -- that is, the description of the source and target relations.
        // The Boolean flags in the .load() method below determine whether we're dealing with the
        // source or the target schema.
        DatabaseSchema databaseSchema = new DatabaseSchema();
        databaseSchema.load(new File(root, "schema/doctors.s-schema.txt"), false);
        databaseSchema.load(new File(root, "schema/doctors.t-schema.txt"), true);
        // We then load dependency files. There is no requirement that s-t TGDs, target TGDs, and target EGDs
        // must be all located in separate files; however, we organized them in such a way for convenience.
        // The scenario we're loading here does not have target TGDs.
        loadCommonFile(databaseSchema, new File(root, "dependencies/doctors.st-tgds.txt"), stDependencies, facts);
        loadCommonFile(databaseSchema, new File(root, "dependencies/doctors.t-egds.txt"), egds, facts);
        // We then load the data. For this, we just pass the directory to the parser.
        CSVParser.parseDirectory(new File(root, "data"), new InputCollector(databaseSchema, null, facts));
        // Finally, we load the query.
        loadCommonFile(databaseSchema, new File(root, "queries/q01.txt"), queries, facts);

        // We now use the serializer to print out everything that was loaded.
        StringWriter output = new StringWriter();
        CommonFormat format = new CommonFormat(databaseSchema, output);
        format.startProcessing();
        for (Rule rule : stDependencies)
            format.processRule(rule);
        for (Rule rule : egds)
            format.processRule(rule);
        for (Atom fact : facts) {
        	List<String> argumentLexicalForms = new ArrayList<String>();
        	List<Boolean> argumentsAreLabeledNulls = new ArrayList<Boolean>();
        	for (int argumentIndex = 0; argumentIndex < fact.getNumberOfArguments(); ++argumentIndex) {
        		Term argument = fact.getArgument(argumentIndex);
        		if (argument instanceof Constant) {
	        		argumentLexicalForms.add(((Constant)argument).getLexicalForm());
	        		argumentsAreLabeledNulls.add(Boolean.FALSE);
        		}
        		else if (argument instanceof LabeledNull) {
	        		argumentLexicalForms.add(((LabeledNull)argument).getName());
	        		argumentsAreLabeledNulls.add(Boolean.TRUE);
        		}
        		else
        			throw new IllegalArgumentException("Facts can contain only constants and labeled nulls as arguments.");
        	}
            format.processFact(fact.getPredicate(), argumentLexicalForms, argumentsAreLabeledNulls);
        }
        for (Rule rule : queries)
            format.processRule(rule);
        format.endProcessing();
        System.out.println(output.getBuffer().toString());
    }
}
