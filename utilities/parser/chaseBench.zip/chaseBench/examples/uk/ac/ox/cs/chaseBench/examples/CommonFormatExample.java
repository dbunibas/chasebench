package uk.ac.ox.cs.chaseBench.examples;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import uk.ac.ox.cs.chaseBench.format.CommonFormat;
import uk.ac.ox.cs.chaseBench.model.Atom;
import uk.ac.ox.cs.chaseBench.model.Constant;
import uk.ac.ox.cs.chaseBench.model.DatabaseSchema;
import uk.ac.ox.cs.chaseBench.model.LabeledNull;
import uk.ac.ox.cs.chaseBench.model.Rule;
import uk.ac.ox.cs.chaseBench.model.Term;
import uk.ac.ox.cs.chaseBench.parser.CSVParser;
import uk.ac.ox.cs.chaseBench.parser.CommonParser;
import uk.ac.ox.cs.chaseBench.processors.InputCollector;

public class CommonFormatExample {

    protected static void loadCommonFile(DatabaseSchema databaseSchema, File file, Set<Rule> rules, Set<Atom> facts) throws Exception {
        Reader fileReader = new FileReader(file);
        try {
            CommonParser parser = new CommonParser(fileReader);
            parser.parse(new InputCollector(databaseSchema, rules, facts));
        }
        finally {
            fileReader.close();
        }
    }

    public static void main(String[] args) throws Exception {
        File root = new File("/Users/bmotik/Dropbox/chaseBench/datasets/doctors");
        Set<Rule> stDependencies = new LinkedHashSet<Rule>();
        Set<Rule> egds = new LinkedHashSet<Rule>();
        Set<Rule> queries = new LinkedHashSet<Rule>();
        Set<Atom> facts = new LinkedHashSet<Atom>();

        DatabaseSchema databaseSchema = new DatabaseSchema();
        databaseSchema.load(new File(root, "schema/doctors.s-schema.txt"), false);
        databaseSchema.load(new File(root, "schema/doctors.t-schema.txt"), true);
        loadCommonFile(databaseSchema, new File(root, "dependencies/doctors.st-tgds.txt"), stDependencies, facts);
        loadCommonFile(databaseSchema, new File(root, "dependencies/doctors.t-egds.txt"), egds, facts);
        CSVParser.parseDirectory(new File(root, "data/10k"), new InputCollector(databaseSchema, null, facts));
        loadCommonFile(databaseSchema, new File(root, "queries/queries.txt"), queries, facts);

        // Print out what was loaded using the searializer.
        StringWriter output = new StringWriter();
        CommonFormat format = new CommonFormat(databaseSchema, output);
        format.startProcessing();
        for (Rule rule : stDependencies)
            format.processRule(rule);
        for (Rule rule : egds)
            format.processRule(rule);
        for (Atom fact : facts) {
        	List<String> argumentLexicalForms = new ArrayList<String>();
        	List<Boolean> argumentsAreLabeledNulls = new ArrayList<Boolean>();
        	for (int argumentIndex = 0; argumentIndex < fact.getNumberOfArguments(); ++argumentIndex) {
        		Term argument = fact.getArgument(argumentIndex);
        		if (argument instanceof Constant) {
	        		argumentLexicalForms.add(((Constant)argument).getLexicalForm());
	        		argumentsAreLabeledNulls.add(Boolean.FALSE);
        		}
        		else if (argument instanceof LabeledNull) {
	        		argumentLexicalForms.add(((LabeledNull)argument).getName());
	        		argumentsAreLabeledNulls.add(Boolean.TRUE);
        		}
        		else
        			throw new IllegalArgumentException("Facts can contain only constants and labeled nulls as arguments.");
        	}
            format.processFact(fact.getPredicate(), argumentLexicalForms, argumentsAreLabeledNulls);
        }
        for (Rule rule : queries)
            format.processRule(rule);
        format.endProcessing();
        System.out.println(output.getBuffer().toString());
    }
}
