package uk.ac.ox.cs.chaseBench.model;

public enum Domain {
	SYMBOL,
	STRING,
	INTEGER,
	DOUBLE
}