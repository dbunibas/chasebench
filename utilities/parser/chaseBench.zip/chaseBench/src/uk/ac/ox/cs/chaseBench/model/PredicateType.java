package uk.ac.ox.cs.chaseBench.model;

public enum PredicateType { SOURCE, TARGET }