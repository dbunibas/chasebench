package uk.ac.ox.cs.chaseBench;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

import uk.ac.ox.cs.chaseBench.format.CommonFormat;
import uk.ac.ox.cs.chaseBench.model.Atom;
import uk.ac.ox.cs.chaseBench.model.Constant;
import uk.ac.ox.cs.chaseBench.model.DatabaseSchema;
import uk.ac.ox.cs.chaseBench.model.LabeledNull;
import uk.ac.ox.cs.chaseBench.model.Predicate;
import uk.ac.ox.cs.chaseBench.model.Rule;
import uk.ac.ox.cs.chaseBench.model.Term;
import uk.ac.ox.cs.chaseBench.parser.CSVParser;
import uk.ac.ox.cs.chaseBench.parser.CommonParser;
import uk.ac.ox.cs.chaseBench.processors.InputCollector;

public class CommonFormatTest {
	protected final DatabaseSchema m_databaseSchema;
    protected final Set<Rule> m_rules;
    protected final Set<Atom> m_facts;

    public CommonFormatTest() {
    	m_databaseSchema = new DatabaseSchema();
        m_rules = new LinkedHashSet<Rule>();
        m_facts = new LinkedHashSet<Atom>();
    }

    protected String getResource(String resourceName) throws IOException {
        InputStream resourceStream = getClass().getResourceAsStream(resourceName);
        if (resourceStream == null)
            throw new IOException("Cannot locate resource '" + resourceName +"'.");
        Reader input = new InputStreamReader(resourceStream);
        try {
            StringBuffer output = new StringBuffer();
            char[] buffer = new char[4096];
            int read;
            while ((read = input.read(buffer)) != -1)
                output.append(buffer, 0, read);
            return output.toString();
        }
        finally {
            input.close();
        }
    }

    protected void loadSchema(Reader reader) throws IOException {
    	m_databaseSchema.load(reader, true);
    }

    protected void loadSchema(String string) throws IOException {
        loadSchema(new StringReader(string));
    }

    protected void loadSchemaResource(String resourceName) throws IOException {
        loadSchema(getResource(resourceName));
    }

    protected void loadCommon(Reader reader) throws IOException {
        InputCollector inputCollector = new InputCollector(m_databaseSchema, m_rules, m_facts);
        CommonParser parser = new CommonParser(reader);
        parser.parse(inputCollector);
    }

    protected void loadCommon(String string) throws IOException {
        loadCommon(new StringReader(string));
    }

    protected void loadCommonResource(String resourceName) throws IOException {
        loadCommon(getResource(resourceName));
    }

    protected void loadCSV(Reader reader, String predicateName) throws IOException {
        InputCollector inputCollector = new InputCollector(m_databaseSchema, m_rules, m_facts);
        inputCollector.startProcessing();
        CSVParser.parse(reader, Predicate.create(predicateName), inputCollector);
        inputCollector.endProcessing();
    }

    protected void loadCSV(String string, String predicateName) throws IOException {
        loadCSV(new StringReader(string), predicateName);
    }

    protected void loadCSVResource(String resourceName, String predicateName) throws IOException {
        loadCSV(getResource(resourceName), predicateName);
    }

    protected void assertCurrent(String expected) {
        assertEquals(expected, serialize());
    }

    protected void assertCurrentResource(String expectedResource) throws IOException {
        assertEquals(getResource(expectedResource), serialize());
    }

    protected String serialize() {
        StringWriter output = new StringWriter();
        CommonFormat commonFormat = new CommonFormat(m_databaseSchema, new PrintWriter(output));
        commonFormat.startProcessing();
        for (Rule rule : m_rules)
        	commonFormat.processRule(rule);
        for (Atom fact : m_facts) {
        	List<String> argumentLexicalForms = new ArrayList<String>();
        	List<Boolean> argumentsAreLabeledNulls = new ArrayList<Boolean>();
        	for (int argumentIndex = 0; argumentIndex < fact.getNumberOfArguments(); ++argumentIndex) {
        		Term argument = fact.getArgument(argumentIndex);
        		if (argument instanceof Constant) {
	        		argumentLexicalForms.add(((Constant)argument).getLexicalForm());
	        		argumentsAreLabeledNulls.add(Boolean.FALSE);
        		}
        		else if (argument instanceof LabeledNull) {
	        		argumentLexicalForms.add(((LabeledNull)argument).getName());
	        		argumentsAreLabeledNulls.add(Boolean.TRUE);
        		}
        		else
        			throw new IllegalArgumentException("Facts can contain only constants and labeled nulls as arguments.");
        	}
            commonFormat.processFact(fact.getPredicate(), argumentLexicalForms, argumentsAreLabeledNulls);
        }
        commonFormat.endProcessing();
        return output.getBuffer().toString();
    }

    @Test
    public void testCommonParser() throws Exception {
    	loadSchemaResource("res/common-schema.txt");
        loadCommonResource("res/common-test.txt");
        assertCurrentResource("res/common-expected.txt");
    }

    @Test
    public void testCSVParser() throws Exception {
    	loadSchemaResource("res/R-schema.txt");
        loadCSVResource("res/R-test.csv", "R");
        assertCurrentResource("res/R-expected.txt");
    }

}
